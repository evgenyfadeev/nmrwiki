#ifndef LINT
static char SCCSid[] = "@(#)Doneshot.c 8/7/99 The University of Manchester.";
#endif

/**********************************************************

	Doneshot - corrected dosytimecubed 04iv01 (previous version saved as Doneshot_04iv01) CLE
	Corrected GAM/MJS 10iv01 - * not + for Dtau in dosytimecubed calculation
	
	Doneshot - Oneshot DOSY sequence based on modifications to the
	Bipolar pulse stimulated echo (BPPSTE) sequence
	Adapted by P Sandor from Vnmr6.1B MDP 26v99.

Parameters:
        delflag   - 'y' runs Doneshot sequence
                    'n' runs a normal s2pul sequence
	del       -  the actual diffusion delay.
	gt1       - total diffusion-encoding pulse width.
        gzlvl1    - diffusion-encoding pulse strength
        gstab     - gradient stabilization delay
        gt3       - spoiling gradient duration
        gzlvl3    - spoiling gradient strength
        gzlvl_max - maximun accepted gradient strength
                       32767 with PerformaII, 2047 with PerformaI
        alpha     - unbalancing factor between bipolar pulses as a
                       proportion of gradient strength (~0.2)

The parameters for the heating gradients (gt4, gzlvl4) are calculated
in the sequence. They cannot be set directly.
tau defined as time between the mid-points of the bipolar diffusion encoding
gradient pulses

	Constant energy dissipation calculation corrected 8vii99

**********************************************************/

#include<standard.h>

pulsesequence()
{
double	alpha = getval("alpha"), 
	gzlvl1 = getval("gzlvl1"),
	gzlvl3 = getval("gzlvl3"),
        gzlvl_max = getval("gzlvl_max"),
	gt1 = getval("gt1"),
	gt3 = getval("gt3"),
	del = getval("del"),
        gstab = getval("gstab"),
	gzlvl4,gt4,Dtau,Ddelta,dosytimecubed, dosyfrq;
char delflag[MAXSTR],phasecycleflag[MAXSTR];

gt4 = 2.0*gt1;
getstr("delflag",delflag);
getstr("phasecycleflag",phasecycleflag);

/* Decrement gzlvl4 as gzlvl1 is incremented, to ensure constant 
   energy dissipation in the gradient coil 
   Current through the gradient coil is proportional to gzlvl */

gzlvl4=sqrt(2.0*gt1*(1+3.0*alpha*alpha)/gt4)*sqrt(gzlvl_max*gzlvl_max/((1+alpha)*(1+alpha))-gzlvl1*gzlvl1);

/* In pulse sequence, del>4.0*pw+3*rof1+2.0*gt1+5.0*gstab+gt3 */

if ((del-(4*pw+3.0*rof1+2.0*gt1+5.0*gstab+gt3)) < 0.0)
   { del=(4*pw+3.0*rof1+2.0*gt1+5.0*gstab+gt3);
     printf("Warning: del too short; reset to minimum value\n");}

if ((d1 - (gt3+gstab) -2.0*(gt4/2.0+gstab)) < 0.0)
   { d1 = (gt3+gstab) -2.0*(gt4/2.0+gstab);
     printf("Warning: d1 too short;  reset to minimum value\n");}

if ((gzlvl1*(1+alpha)) > gzlvl_max)
   { printf("Max. grad. amplitude exceeded: reduce either gzlvl1 or alpha\n");
     abort(1); }

if (ni > 0.0)
   { printf("This is a 2D, not a 3D dosy sequence: please set ni to zero\n");
     abort(1); }

Ddelta=gt1;
Dtau=2.0*pw+gstab+gt1/2.0+rof1;
dosyfrq = getval("sfrq");
dosytimecubed=del+(gt1*((alpha*alpha-2)/6.0))+Dtau*((alpha*alpha-1.0)/2.0);
dosytimecubed=(gt1*gt1)*dosytimecubed;
putCmd("makedosyparams(%e,%e)\n",dosytimecubed,dosyfrq);

/* phase cycling calculation */

if(delflag[0]=='y')
{
 if(phasecycleflag[0]=='y')
	{
	mod2(ct,v1); dbl(v1,v1); hlv(ct,v2);
	mod2(v2,v3); dbl(v3,v3); hlv(v2,v2);
	mod2(v2,v4); add(v1,v4,v1);                    /*    v1      */
	hlv(v2,v2); add(v2,v3,v4);                     /*    v4      */
	hlv(v2,v2); mod2(v2,v3); dbl(v3,v5);
	hlv(v2,v2); mod2(v2,v3); dbl(v3,v3);           /*    v3      */
	hlv(v2,v2); mod2(v2,v6); add(v5,v6,v5);        /*    v5      */
	hlv(v2,v2); mod2(v2,v2); dbl(v2,v2);           /*    v2      */
	assign(v1,oph); dbl(v2,v6); sub(oph,v6,oph);
	add(v3,oph,oph); sub(oph,v4,oph); dbl(v5,v6);
	add(v6,oph,oph); mod4(oph,oph);                /* receiver phase */
	}
	else assign(zero,oph);
}
   status(A);

   if(delflag[0]=='y')
	{
      	zgradpulse(-1.0*gzlvl4,gt4/2.0); /* 1st dummy heating pulse */
   	delay(gstab);

	zgradpulse(gzlvl4,gt4/2.0); /* 2nd dummy heating pulse */
	delay(gstab);

	delay(d1 - (gt3+gstab) -2.0*(gt4/2.0+gstab));

	zgradpulse(-1.0*gzlvl3,gt3); /* Spoiler gradient balancing pulse */
	delay(gstab); 
        }
	else delay(d1);

   status(B); /* first part of sequence */
   if(delflag[0]=='y')
   {
   	if(gt1>0 && gzlvl1>0)
   	{
   	rgpulse(pw, v1, rof1, 0.0);		/* first 90, v1 */

	zgradpulse(gzlvl1*(1.0-alpha),gt1/2.0); /*1st main gradient pulse*/
   	delay(gstab);
	rgpulse(pw*2.0, v2, rof1, 0.0);		/* first 180, v2 */

	zgradpulse(-1.0*gzlvl1*(1.0+alpha),gt1/2.0); /*2nd main grad. pulse*/
   	delay(gstab);
   	rgpulse(pw, v3, rof1, 0.0);		/* second 90, v3 */

	zgradpulse(gzlvl1*2.0*alpha,gt1/2.0); /*Lock refocussing pulse*/
   	delay(gstab);

	zgradpulse(gzlvl3,gt3); /* Spoiler gradient balancing pulse */
   	delay(gstab);

	delay(del-4.0*pw-3.0*rof1-2.0*gt1-5.0*gstab-gt3); /* diffusion delay */

	zgradpulse(2.0*alpha*gzlvl1,gt1/2.0); /*Lock refocussing pulse*/
   	delay(gstab);
   	rgpulse(pw, v4, rof1, 0.0);		/* third 90, v4 */

	zgradpulse(gzlvl1*(1.0-alpha),gt1/2.0); /*3rd main gradient pulse*/
   	delay(gstab);
	rgpulse(pw*2.0, v5, rof1, rof2);	/* second 180, v5 */

	zgradpulse(-1.0*(1.0+alpha)*gzlvl1,gt1/2.0); /*4th main grad. pulse*/
   	delay(gstab);
   	}
   }
   else rgpulse(pw,oph,rof1,rof2);
   status(C);
}

/****************************************************************************
256 (or 16,32,64,128) steps phase cycle
Order of cycling: v1 (0,2), v4(0,2), v1(1,3), v4(1,3), v5(0,2), v3(0,2),
v5(1,3) v2(0,2)

receiver = v1-2*v2+v3-v4+2*v5

Coherence pathway :

	90	180	 90		90	180	  Acq.
+2
                  ________                _______
+1               |        |              |       |
                 |        |              |       |
 0------|        |        |--------------|       |
        |        |                               |
-1      |________|                               |____________________

-2
	v1       v2        v3             v4      v5
****************************************************************************/
